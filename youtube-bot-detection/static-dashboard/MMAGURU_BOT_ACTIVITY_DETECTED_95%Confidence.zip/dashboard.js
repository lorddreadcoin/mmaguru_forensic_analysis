// Set current date
document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
});

// Chart configurations
const chartColors = {
    jesse: 'rgba(0, 255, 0, 0.8)',
    mmaGuru: 'rgba(255, 0, 0, 0.8)',
    bisping: 'rgba(0, 255, 0, 0.8)',
    chael: 'rgba(0, 255, 0, 0.8)',
    borderGreen: '#00ff00',
    borderRed: '#ff0000',
    gridColor: 'rgba(0, 255, 0, 0.1)'
};

const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            display: false
        },
        tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.9)',
            titleColor: '#00ff00',
            bodyColor: '#00ff00',
            borderColor: '#00ff00',
            borderWidth: 1
        }
    },
    scales: {
        y: {
            grid: {
                color: chartColors.gridColor
            },
            ticks: {
                color: '#00ff00'
            }
        },
        x: {
            grid: {
                color: chartColors.gridColor
            },
            ticks: {
                color: '#00ff00'
            }
        }
    }
};

// Initialize charts when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeSpikeChart();
    initializeVarianceChart();
    initializeEngagementChart();
    initializeHeatmapChart();
});

function initializeSpikeChart() {
    const ctx = document.getElementById('spikeChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jesse', 'MMA GURU', 'Bisping', 'Chael'],
            datasets: [{
                label: 'Spike Ratio',
                data: [2.33, 5.6, 1.89, 1.91],
                backgroundColor: [
                    chartColors.jesse,
                    chartColors.mmaGuru,
                    chartColors.bisping,
                    chartColors.chael
                ],
                borderColor: [
                    chartColors.borderGreen,
                    chartColors.borderRed,
                    chartColors.borderGreen,
                    chartColors.borderGreen
                ],
                borderWidth: 2
            }]
        },
        options: {
            ...chartOptions,
            plugins: {
                ...chartOptions.plugins,
                title: {
                    display: true,
                    text: 'Spike Ratio: How Fast Views Jump',
                    color: '#ff6600',
                    font: {
                        size: 16
                    }
                },
                subtitle: {
                    display: true,
                    text: '2-3x = Natural | >5x = Bot',
                    color: '#00ff00',
                    font: {
                        size: 12
                    }
                },
                annotation: {
                    annotations: {
                        line1: {
                            type: 'line',
                            yMin: 3,
                            yMax: 3,
                            borderColor: 'yellow',
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                content: 'Organic threshold',
                                enabled: true,
                                position: 'end'
                            }
                        },
                        line2: {
                            type: 'line',
                            yMin: 5,
                            yMax: 5,
                            borderColor: 'red',
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                content: 'Bot threshold',
                                enabled: true,
                                position: 'end'
                            }
                        }
                    }
                }
            }
        }
    });
}

function initializeVarianceChart() {
    const ctx = document.getElementById('varianceChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jesse', 'MMA GURU', 'Bisping', 'Chael'],
            datasets: [{
                label: 'Variance',
                data: [0.42, 0.08, 0.35, 0.38],
                backgroundColor: [
                    chartColors.jesse,
                    chartColors.mmaGuru,
                    chartColors.bisping,
                    chartColors.chael
                ],
                borderColor: [
                    chartColors.borderGreen,
                    chartColors.borderRed,
                    chartColors.borderGreen,
                    chartColors.borderGreen
                ],
                borderWidth: 2
            }]
        },
        options: {
            ...chartOptions,
            plugins: {
                ...chartOptions.plugins,
                title: {
                    display: true,
                    text: 'Pattern Variance: Natural vs Artificial',
                    color: '#ff6600',
                    font: {
                        size: 16
                    }
                },
                subtitle: {
                    display: true,
                    text: '>0.3 = Natural Heartbeat | <0.1 = Flat/Bot',
                    color: '#00ff00',
                    font: {
                        size: 12
                    }
                }
            }
        }
    });
}

function initializeEngagementChart() {
    const ctx = document.getElementById('engagementChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jesse', 'MMA GURU', 'Bisping', 'Chael'],
            datasets: [{
                label: 'Engagement %',
                data: [3.2, 0.5, 3.8, 4.1],
                backgroundColor: [
                    chartColors.jesse,
                    chartColors.mmaGuru,
                    chartColors.bisping,
                    chartColors.chael
                ],
                borderColor: [
                    chartColors.borderGreen,
                    chartColors.borderRed,
                    chartColors.borderGreen,
                    chartColors.borderGreen
                ],
                borderWidth: 2
            }]
        },
        options: {
            ...chartOptions,
            plugins: {
                ...chartOptions.plugins,
                title: {
                    display: true,
                    text: 'Engagement Rate: Real People Interact',
                    color: '#ff6600',
                    font: {
                        size: 16
                    }
                },
                subtitle: {
                    display: true,
                    text: '2.5-4.5% = Real Humans | <1% = Bots Don\'t Comment',
                    color: '#00ff00',
                    font: {
                        size: 12
                    }
                }
            }
        }
    });
}

function initializeHeatmapChart() {
    const ctx = document.getElementById('heatmapChart');
    if (!ctx) return;
    
    // Create a simulated heatmap using a grouped bar chart
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Spike Ratio', 'Variance', 'Engagement'],
            datasets: [
                {
                    label: 'Jesse',
                    data: [2.33, 0.42, 3.2],
                    backgroundColor: 'rgba(0, 255, 0, 0.6)',
                    borderColor: chartColors.borderGreen,
                    borderWidth: 1
                },
                {
                    label: 'MMA GURU',
                    data: [5.6, 0.08, 0.5],
                    backgroundColor: 'rgba(255, 0, 0, 0.6)',
                    borderColor: chartColors.borderRed,
                    borderWidth: 1
                },
                {
                    label: 'Bisping',
                    data: [1.89, 0.35, 3.8],
                    backgroundColor: 'rgba(0, 255, 0, 0.6)',
                    borderColor: chartColors.borderGreen,
                    borderWidth: 1
                },
                {
                    label: 'Chael',
                    data: [1.91, 0.38, 4.1],
                    backgroundColor: 'rgba(0, 255, 0, 0.6)',
                    borderColor: chartColors.borderGreen,
                    borderWidth: 1
                }
            ]
        },
        options: {
            ...chartOptions,
            plugins: {
                ...chartOptions.plugins,
                legend: {
                    display: true,
                    labels: {
                        color: '#00ff00'
                    }
                },
                title: {
                    display: true,
                    text: 'All Metrics Comparison',
                    color: '#ff6600',
                    font: {
                        size: 16
                    }
                }
            }
        }
    });
}
